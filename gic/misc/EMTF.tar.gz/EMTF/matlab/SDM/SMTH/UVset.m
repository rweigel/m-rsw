eigmin = 2;
S = Sdms.S(:,:,ib);
uhat = TF_smth(:,:,ib);
var = Sdms.var(:,ib);
lambda = Sdms.lambda(:,ib);
neig = sum(lambda > eigmin);
