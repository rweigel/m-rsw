function [nrect] = adjustY(nrect,inOut);

nrect(4) = nrect(4)*inOut;
nrect(2) = 1-(1-nrect(2))*inOut;
