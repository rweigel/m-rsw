function [inds] = selctCH(S,SNRavg,fac);
%   returns indices of "good" channels 
