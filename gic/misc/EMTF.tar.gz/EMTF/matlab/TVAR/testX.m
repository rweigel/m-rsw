TYPE.SDMsig = 'SDMsig';
TYPE.CcovSig = 'CcovSig';
TYPE.CcohSig = 'CcovSig';
