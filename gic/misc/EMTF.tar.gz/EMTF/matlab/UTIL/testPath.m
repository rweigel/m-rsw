path('/home/server/homes/pi/egbert/progs/EMTF/matlab/SDM',path);
path('/home/server/homes/pi/egbert/progs/EMTF/matlab/UTIL',path);
path('/home/server/homes/pi/egbert/progs/EMTF/matlab/IN',path);

