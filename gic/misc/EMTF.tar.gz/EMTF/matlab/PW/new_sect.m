%  just a few things to set up a new figure
T = PW(1,1).T;
labels = [];
ifref = [];
v1 = [];
sig_v1 = [];
pwstmon;

plot_sect;
NEW_ROT = 0;
