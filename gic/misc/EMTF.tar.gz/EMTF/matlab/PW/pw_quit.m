delete(h_pwdialog);
for h = h_plots
   figure(h);delete(h);
end
