    function [lims] = sect_lims(A,B)

%    lims(1:2) = [median(min(A')) median(max(A'))];
%    lims(3:4) = [median(min(B')) median(max(B'))];
 	lims(1:2) = [0.3 1.7];
 	lims(3:4) = [-15 15];
